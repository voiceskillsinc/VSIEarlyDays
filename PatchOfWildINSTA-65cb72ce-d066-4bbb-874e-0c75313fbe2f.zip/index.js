const main = require('./main.json');
const Alexa = require('ask-sdk-core');
const title = 'Patch of Wild';
const BREAK = '<break time="3s"/>';
const cardImage = 'https://s3.amazonaws.com/rememberwhenskills/POWLOGO.png';

const GetRemoteDataHandler = {
  canHandle(handlerInput) {
    const request = handlerInput.requestEnvelope.request;
    return (
      handlerInput.requestEnvelope.request.type === 'LaunchRequest' ||
      (
        request.type === 'IntentRequest' &&
        (
          request.intent.name === 'GetRemoteDataIntent'
        )
      )
    );
  },
  async handle(handlerInput) {
    if (supportsAPL(handlerInput)) {
    let outputSpeech = 'Your viewing images from the Patch of Wild Instagram Feed';
    let picture  = 'This is the default message.';
    let explan = 'Turn your IG account into a custom Skill! \n Ask me how \n jody@voiceskillsinc.com';
    await getRemoteData('https://spreadsheets.google.com/feeds/list/1-5Rxrk6Uay1frT5a7Ka0YbASNPPW4l5pRbuDapDhqQU/od6/public/basic?alt=json')
      .then((response) => {
        const data = JSON.parse(response);
        const random = Math.floor(Math.random() * `${data.feed.openSearch$totalResults.$t}`);
        outputSpeech = "Hello, welcome to Patch of Wild!, Today's message " + `${data.feed.entry[random].content.$t}` + BREAK  + "Would you like another image and message?";
        picture = `${data.feed.entry[random].title.$t}`;
        for (let i = 0; i < data.length; i++) {
          if (i === 0) {
            //first record
            outputSpeech = "Hello, welcome to Patch of Wild!, Today's message " + `${data.feed.entry[random].content.$t}` + BREAK + "Would you like another image and message?";
            picture = `${data.feed.entry[random].title.$t}`;
          } else if (i === data.length - 1) {
            //last record
            outputSpeech = "Hello, welcome to Patch of Wild!, Today's message " + `${data.feed.entry[random].content.$t}` + BREAK + "Would you like another image and message?";
            picture = `${data.feed.entry[random].title.$t}`;
          } else {
            //middle record(s)
            outputSpeech = "Hello, welcome to Patch of Wild!, Today's message " + `${data.feed.entry[random].content.$t}` + BREAK + "Would you like another image and message?";
            picture = `${data.feed.entry[random].title.$t}`;
          }
        }
      })
      .catch((err) => {
        err.message = "Sorry, I wasn't able to access the Patch of Wild Instagram Feed.";
        outputSpeech = err.message;
      });
          
          
          const responseBuilder = handlerInput.responseBuilder;
          const cardText = explan;
          
          return responseBuilder
              .speak(outputSpeech)
              .reprompt("Would you like another image and message?")
              .withStandardCard(title, cardText, picture, picture)
              .addDirective({
                type: 'Alexa.Presentation.APL.RenderDocument',
                version: '1.0',
                document: main,
                datasources: {
                  "myDocumentData": {
                  "title": picture
                  }
                }
            })
              .getResponse();
      } else {
    const responseBuilder = handlerInput.responseBuilder;
    let outputSpeech = 'Your viewing images from the Patch of Wild Instagram Feed';
    let picture  = 'This is the default message.';
    let explan = 'Turn your IG account into a custom Skill! \n Ask me how \n jody@voiceskillsinc.com';
    await getRemoteData('https://spreadsheets.google.com/feeds/list/1-5Rxrk6Uay1frT5a7Ka0YbASNPPW4l5pRbuDapDhqQU/od6/public/basic?alt=json')
      .then((response) => {
        const data = JSON.parse(response);
        const random = Math.floor(Math.random() * `${data.feed.openSearch$totalResults.$t}`);
        outputSpeech = "Hello, welcome to Patch of Wild!, Check your campanion app! Today's message " + `${data.feed.entry[random].content.$t}` + BREAK + "Would you like another image and message?";
        picture = `${data.feed.entry[random].title.$t}`;
        for (let i = 0; i < data.length; i++) {
          if (i === 0) {
            //first record
            outputSpeech = "Hello, welcome to Patch of Wild!, Check your campanion app! Today's message " + `${data.feed.entry[random].content.$t}` + BREAK + "Would you like another image and message?",
            picture = `${data.feed.entry[random].title.$t}`;
          } else if (i === data.length - 1) {
            //last record
            outputSpeech = "Hello, welcome to Patch of Wild!, Check your campanion app! Today's message " + `${data.feed.entry[random].content.$t}` + BREAK + "Would you like another image and message?";
            picture = `${data.feed.entry[random].title.$t}`;
          } else {
            //middle record(s)
            outputSpeech = "Hello, welcome to Patch of Wild!, Check your campanion app! Today's message " + `${data.feed.entry[random].content.$t}` + BREAK + "Would you like another image and message?";
            picture = `${data.feed.entry[random].title.$t}`;
          }
        }
      })
      .catch((err) => {
        err.message = "Sorry, I wasn't able to access the Patch of Wild Instagram Feed.";
        outputSpeech = err.message;
      });
       return responseBuilder
            .speak(outputSpeech)
            .reprompt("Would you like another image and message?")
            .withStandardCard(title, explan, picture, picture)
            .getResponse();
      }
  },
};

const restartHandler = {
  canHandle(handlerInput) {
    return handlerInput.requestEnvelope.request.type === 'IntentRequest'
      && (handlerInput.requestEnvelope.request.intent.name === 'AMAZON.NavigateHomeIntent'
        || handlerInput.requestEnvelope.request.intent.name === 'AMAZON.MoreIntent'
        || handlerInput.requestEnvelope.request.intent.name === 'AMAZON.StartOverIntent'
        || handlerInput.requestEnvelope.request.intent.name === 'AMAZON.YesIntent');
  },
  async handle(handlerInput) {
    if (supportsAPL(handlerInput)) {
    let outputSpeech = 'Your viewing images from the Patch of Wild Instagram Feed';
    let picture  = 'This is the default message.';
    let explan = 'Turn your IG account into a custom Skill! \n Ask me how \n jody@voiceskillsinc.com';
    await getRemoteData('https://spreadsheets.google.com/feeds/list/1-5Rxrk6Uay1frT5a7Ka0YbASNPPW4l5pRbuDapDhqQU/od6/public/basic?alt=json')
      .then((response) => {
        const data = JSON.parse(response);
        const random = Math.floor(Math.random() * `${data.feed.openSearch$totalResults.$t}`);
        outputSpeech = "Today's message " + `${data.feed.entry[random].content.$t}` + BREAK  + "Would you like another image and message?";
        picture = `${data.feed.entry[random].title.$t}`;
        for (let i = 0; i < data.length; i++) {
          if (i === 0) {
            //first record
            outputSpeech = "Today's message " + `${data.feed.entry[random].content.$t}` + BREAK + "Would you like another image and message?";
            picture = `${data.feed.entry[random].title.$t}`;
          } else if (i === data.length - 1) {
            //last record
            outputSpeech = "Today's message " + `${data.feed.entry[random].content.$t}` + BREAK + "Would you like another image and message?";
            picture = `${data.feed.entry[random].title.$t}`;
          } else {
            //middle record(s)
            outputSpeech = "Today's message " + `${data.feed.entry[random].content.$t}` + BREAK + "Would you like another image and message?";
            picture = `${data.feed.entry[random].title.$t}`;
          }
        }
      })
      .catch((err) => {
        err.message = "Sorry, I wasn't able to access the Patch of Wild Instagram Feed.";
        outputSpeech = err.message;
      });
          
          
          const responseBuilder = handlerInput.responseBuilder;
          const cardText = explan;
          
          return responseBuilder
              .speak(outputSpeech)
              .reprompt("Would you like another image and message?")
              .withStandardCard(title, cardText, picture, picture)
              .addDirective({
                type: 'Alexa.Presentation.APL.RenderDocument',
                version: '1.0',
                document: main,
                datasources: {
                  "myDocumentData": {
                  "title": picture
                  }
                }
            })
              .getResponse();
      } else{
    const responseBuilder = handlerInput.responseBuilder;
    let outputSpeech = 'Your viewing images from the Patch of Wild Instagram Feed';
    let picture  = 'This is the default message.';
    let explan = 'Turn your IG account into a custom Skill! \n Ask me how \n jody@voiceskillsinc.com';
    await getRemoteData('https://spreadsheets.google.com/feeds/list/1-5Rxrk6Uay1frT5a7Ka0YbASNPPW4l5pRbuDapDhqQU/od6/public/basic?alt=json')
      .then((response) => {
        const data = JSON.parse(response);
        const random = Math.floor(Math.random() * `${data.feed.openSearch$totalResults.$t}`);
        outputSpeech = "Check your campanion app! Today's message " + `${data.feed.entry[random].content.$t}` + BREAK + "Would you like another image and message?";
        picture = `${data.feed.entry[random].title.$t}`;
        for (let i = 0; i < data.length; i++) {
          if (i === 0) {
            //first record
            outputSpeech = "Check your campanion app! Today's message " + `${data.feed.entry[random].content.$t}` + BREAK + "Would you like another image and message?";
            picture = `${data.feed.entry[random].title.$t}`;
          } else if (i === data.length - 1) {
            //last record
            outputSpeech = "Check your campanion app! Today's message " + `${data.feed.entry[random].content.$t}` + BREAK + "Would you like another image and message?";
            picture = `${data.feed.entry[random].title.$t}`;
          } else {
            //middle record(s)
            outputSpeech = "Check your campanion app! Today's message " + `${data.feed.entry[random].content.$t}` + BREAK + "Would you like another image and message?";
            picture = `${data.feed.entry[random].title.$t}`;
          }
        }
      })
      .catch((err) => {
        err.message = "Sorry, I wasn't able to access the Patch of Wild Instagram Feed.";
        outputSpeech = err.message;
      });
       return responseBuilder
            .speak(outputSpeech)
            .reprompt("Would you like another image and message?")
            .withStandardCard(title, explan, picture, picture)
            .getResponse();
      }
  },
};

const chooseHandler = {
  canHandle(handlerInput) {
    return handlerInput.requestEnvelope.request.type === 'IntentRequest'
      && (handlerInput.requestEnvelope.request.intent.name === 'chooseIntent');
  },
  async handle(handlerInput) {
  const number = handlerInput.requestEnvelope.request.intent.slots.itemNumber.value;
    
    if (supportsAPL(handlerInput)) {
    let outputSpeech = 'Your viewing images from the Patch of Wild Instagram Feed';
    let picture  = 'This is the default message.';
    let reprompt  = 'Your viewing images from the Patch of Wild Instagram Feed';
    let explan = 'Turn your IG account into a custom Skill! \n Ask me how \n jody@voiceskillsinc.com';
    await getRemoteData('https://spreadsheets.google.com/feeds/list/1-5Rxrk6Uay1frT5a7Ka0YbASNPPW4l5pRbuDapDhqQU/od6/public/basic?alt=json')
      .then((response) => {
        const data = JSON.parse(response);
        const feedNumber = `${data.feed.openSearch$totalResults.$t}`;
        const startIndex = `${data.feed.openSearch$startIndex.$t}`;
        const FinalNumber = feedNumber - startIndex;
        if (number < feedNumber){
        outputSpeech = "Today's message " + `${data.feed.entry[number].content.$t}` + BREAK  + "Would you like another image and message?";
        picture = `${data.feed.entry[number].title.$t}`;
        }else if (number > `${data.feed.openSearch$totalResults.$t}` - 1 ){
        outputSpeech = "Today's message " + `${data.feed.entry[0].content.$t}` + BREAK  + " Would you like another image and message?";
        reprompt = "Today's message " + `${data.feed.entry[0].content.$t}` + " Please try again or say stop to exit."; 
        picture = `${data.feed.entry[0].title.$t}`;
        }else if (`${data.feed.openSearch$totalResults.$t}`){
        outputSpeech = "Today's message " +  `${data.feed.entry[FinalNumber].content.$t}` + BREAK  + "Would you like another image and message?";
        picture = `${data.feed.entry[FinalNumber].title.$t}`;
        }})
        .catch((err) => {
        err.message = "Sorry, I wasn't able to access the Patch of Wild Instagram Feed.";
        outputSpeech = err.message;
      });
      
      const responseBuilder = handlerInput.responseBuilder;
      const cardText = explan;
          
          return responseBuilder
              .speak(outputSpeech)
              .reprompt(reprompt)
              .withStandardCard(title, cardText, picture, picture)
              .addDirective({
                type: 'Alexa.Presentation.APL.RenderDocument',
                version: '1.0',
                document: main,
                datasources: {
                  "myDocumentData": {
                  "title": picture
                  }
                }
            })
              .getResponse();
      } else {
    const responseBuilder = handlerInput.responseBuilder;
    let outputSpeech = 'Your viewing images from the Patch of Wild Instagram Feed';
    let picture  = 'This is the default message.';
    let reprompt  = 'Your viewing images from the Patch of Wild Instagram Feed';
    let explan = 'Turn your IG account into a custom Skill! \n Ask me how \n jody@voiceskillsinc.com';
    await getRemoteData('https://spreadsheets.google.com/feeds/list/1-5Rxrk6Uay1frT5a7Ka0YbASNPPW4l5pRbuDapDhqQU/od6/public/basic?alt=json')
      .then((response) => {
        const data = JSON.parse(response);
        const feedNumber = `${data.feed.openSearch$totalResults.$t}`;
        const startIndex = `${data.feed.openSearch$startIndex.$t}`;
        const FinalNumber = feedNumber - startIndex;
        if (number < feedNumber){
        outputSpeech = "Today's message " + `${data.feed.entry[number].content.$t}` + BREAK  + "Would you like another image and message?";
        picture = `${data.feed.entry[number].title.$t}`;
        }else if (number > `${data.feed.openSearch$totalResults.$t}` - 1){
        outputSpeech = "Today's message " + `${data.feed.entry[0].content.$t}` +  FinalNumber + BREAK  + " Would you like another image and message?";
        reprompt = "Today's message " + `${data.feed.entry[0].content.$t}` + FinalNumber + " Please try again or say stop to exit."; 
        picture = `${data.feed.entry[0].title.$t}`;
        }else if (`${data.feed.openSearch$totalResults.$t}`){
        outputSpeech = "Today's message " +  `${data.feed.entry[FinalNumber].content.$t}` + BREAK  + "Would you like another image and message?";
        picture = `${data.feed.entry[FinalNumber].title.$t}`;
        }})
        .catch((err) => {
        err.message = "Sorry, I wasn't able to access the Patch of Wild Instagram Feed.";
        outputSpeech = err.message;
      });
      
       return responseBuilder
            .speak(outputSpeech)
            .reprompt(reprompt)
            .withStandardCard(title, explan, picture, picture)
            .getResponse();
      }
  },
};

const HelpIntentHandler = {
  canHandle(handlerInput) {
    return handlerInput.requestEnvelope.request.type === 'IntentRequest'
      && (handlerInput.requestEnvelope.request.intent.name === 'AMAZON.HelpIntent'
      ||  handlerInput.requestEnvelope.request.intent.name === 'AMAZON.FallbackIntent');
  },
  handle(handlerInput) {
    const speechText = 'This Skill only displays images and captions from the Patch of Wild Instagram Feed. Would you like another image and message?';

    return handlerInput.responseBuilder
      .speak(speechText)
      .reprompt(speechText)
      .getResponse();
  },
};

const CancelAndStopIntentHandler = {
  canHandle(handlerInput) {
    return handlerInput.requestEnvelope.request.type === 'IntentRequest'
      && (handlerInput.requestEnvelope.request.intent.name === 'AMAZON.CancelIntent'
        || handlerInput.requestEnvelope.request.intent.name === 'AMAZON.StopIntent'
        || handlerInput.requestEnvelope.request.intent.name === 'AMAZON.NoIntent');
  },
  handle(handlerInput) {
    const speechText = 'Thanks for visiting, Patch of Wild';
    const cardTitle = "For more content like this visit:";
    const cardText = "Instagram: Instagram.com/PatchofWild \n Website: https://voiceskillsinc.com \n Contact: jody@voiceskillsinc.com";

    return handlerInput.responseBuilder
      .speak(speechText)
      .withStandardCard(cardTitle, cardText, cardImage, cardImage)
      .getResponse();
  },
};

const SessionEndedRequestHandler = {
  canHandle(handlerInput) {
    return handlerInput.requestEnvelope.request.type === 'SessionEndedRequest';
  },
  handle(handlerInput) {
    console.log(`Session ended with reason: ${handlerInput.requestEnvelope.request.reason}`);

    return handlerInput.responseBuilder.getResponse();
  },
};

const ErrorHandler = {
  canHandle() {
    return true;
  },
  handle(handlerInput, error) {
    console.log(`Error handled: ${error.message}`);

    return handlerInput.responseBuilder
      .speak('Sorry, I can\'t understand the command. Please say again.')
      .reprompt('Sorry, I can\'t understand the command. Please say again.')
      .getResponse();
  },
};

const getRemoteData = function (url) {
  return new Promise((resolve, reject) => {
    const client = url.startsWith('https') ? require('https') : require('http');
    const request = client.get(url, (response) => {
      if (response.statusCode < 200 || response.statusCode > 299) {
        reject(new Error('Failed with status code: ' + response.statusCode));
      }
      const body = [];
      response.on('data', (chunk) => body.push(chunk));
      response.on('end', () => resolve(body.join('')));
    });
    request.on('error', (err) => reject(err));
  });
};

function supportsAPL(handlerInput) {
  const supportedInterfaces = handlerInput.requestEnvelope.context
    .System.device.supportedInterfaces;
  const aplInterface = supportedInterfaces['Alexa.Presentation.APL'];
  return aplInterface != null && aplInterface !== undefined;
}

const skillBuilder = Alexa.SkillBuilders.custom();

exports.handler = skillBuilder
  .addRequestHandlers(
    GetRemoteDataHandler,
    restartHandler,
    chooseHandler,
    HelpIntentHandler,
    CancelAndStopIntentHandler,
    SessionEndedRequestHandler
  )
  .addErrorHandlers(ErrorHandler)
  .lambda();

//////////////////////////////////

