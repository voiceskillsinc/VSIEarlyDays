exports.skill = {
  appId: 'amzn1.ask.skill.05356ecf-b7d2-406b-8244-d2959e7a29bd',
  dynamoDBTableName: 'ten-minutes-terror',
};

exports.audioData = [
  {
    "duration": "06:45",
    "title": "Pro Hrabrogo Zaica Dlinnye Ushi Kosye Glaza Korotkii Hvost",
    "orig_title": "\u041f\u0440\u043e \u0445\u0440\u0430\u0431\u0440\u043e\u0433\u043e \u0417\u0430\u0439\u0446\u0430-\u0434\u043b\u0438\u043d\u043d\u044b\u0435 \u0443\u0448\u0438, \u043a\u043e\u0441\u044b\u0435 \u0433\u043b\u0430\u0437\u0430, \u043a\u043e\u0440\u043e\u0442\u043a\u0438\u0439 \u0445\u0432\u043e\u0441\u0442",
    "url": "https://stat1.deti-online.com/a/rcwtCQIZ6AY97mNJIkUwdQ/1528977631/files/skazki/skazki-mamina-sibirjaka/pro-hrabrogo-zaica-dlinnye-ushi-kosye-glaza-korotkii-hvost.mp3"
  },
  {
    "duration": "46:17",
    "title": "Pro Slavnogo Carja Goroha",
    "orig_title": "\u041f\u0440\u043e \u0441\u043b\u0430\u0432\u043d\u043e\u0433\u043e \u0446\u0430\u0440\u044f \u0413\u043e\u0440\u043e\u0445\u0430",
    "url": "https://stat2.deti-online.com/a/Xcdee8SrpEh-X0G-gi17ow/1528992388/files/skazki/skazki-mamina-sibirjaka/pro-slavnogo-carja-goroha.mp3"
  },
  {
    "duration": "19:01",
    "title": "Pro Repku",
    "orig_title": "\u041f\u0440\u043e \u0440\u0435\u043f\u043a\u0443",
    "url": "https://stat2.deti-online.com/a/eucbN-r6vku7kRmLGV3QZA/1528973999/files/skazki/rasskazy-nosova/pro-repku.mp3"
  },
  {
    "duration": "00:39",
    "title": "Elka",
    "orig_title": "\u0415\u043b\u043a\u0430",
    "url": "https://stat1.deti-online.com/a/113fDRADkXMesKQfqTtBzw/1528995265/files/skazki/skazki-chukovskogo/elka.mp3"
  }
];
